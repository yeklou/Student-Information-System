package Sis;
public class Student {
    private String ID;
    private String Name;

    public Student(String ID, String Name){
        this.ID = ID;
        this.Name = Name;
    }

    public String getID(){
        return ID;
    }

    public String getName(){
        return Name;
    }

    public void setID(String ID){
        this.ID = ID;
    }

    public void setName(String Name){
        this.Name = Name;
    }

    public void displayStudent(){
        System.out.println("ID: " + ID + ", Name: " + Name);
    }
}
