package Sis;

import java.util.ArrayList;
import java.util.List;

public class StudentInformationSystem {
    // Implement student management system functionalities using collection classes
    private List<Student> students = new ArrayList<>();
    private List<Enrollment> enrollments = new ArrayList<>();

    //Manage Students (Add, Search, and List out Students)

    public void addStudent(Student student) {
        students.add(student);
        System.out.println("Student added successfully.");
    }

    public boolean searchingStudentByID(String ID) {
        for (Student student : students) {
            if (student.getID().equalsIgnoreCase(ID)) {
                System.out.println("Student Found: ID: " + student.getID() + ", Name: " + student.getName());
                return true;
            }
        }
        System.out.println("Student with ID " + ID + " not found.");
        return false;
    }

    public List<Student> getAllStudents() {
        return students;
    }

    public void displayStudent() {
        System.out.println("All Students: ");
        for (Student student : students) {
            student.displayStudent();
        }
    }

    //Manage Students Enrollment Status

    public Student getStudentByID(String id) {
       for (Student student : students) {
           if (student.getID().equalsIgnoreCase(id)) {
              return student;
            }
        }
    return null;
    }

    public void addEnrollment(Enrollment enrollment) {
        enrollments.add(enrollment);
    }

}
