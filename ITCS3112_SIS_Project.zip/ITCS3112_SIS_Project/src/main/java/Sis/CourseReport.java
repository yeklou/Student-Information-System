
package Sis;

// CourseReport implements ReportGenerator to show a course-specific report
public class CourseReport implements ReportGenerator {
    private Course course;

    public CourseReport(Course course) {
        this.course = course;
    }

    @Override
    public void generateReport() {
        System.out.println("=== Course Report ===");
        System.out.println("Course: " + course.getCourseName());
        System.out.println("Course Code: " + course.getCourseCode());
        System.out.println("Credit Hours: " + course.getCreditHours());
        System.out.println("Instructor: " + course.getInstructor());
        System.out.println("Enrolled Students: " + course.getEnrolledStudents().size());
        for (Student s : course.getEnrolledStudents()) {
            System.out.println("- " + s.getID() + ": " + s.getName());
        }
    }
}
