package Sis;

public interface ReportGenerator {
    void generateReport();
}
