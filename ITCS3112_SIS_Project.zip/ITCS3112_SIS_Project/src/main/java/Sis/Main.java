package Sis;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        StudentInformationSystem sis = new StudentInformationSystem();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Student Information System ---");
            System.out.println("1. Add Student");
            System.out.println("2. Search Student by ID");
            System.out.println("3. Display All Students");
            System.out.println("4. Enroll Student in Course"); // New Option
            System.out.println("0. Exit");
            System.out.println("");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter Student Name: ");
                    String name = scanner.nextLine();
                    sis.addStudent(new Student(id, name));
                    break;
                case 2:
                    System.out.print("Enter Student ID to search: ");
                    String searchId = scanner.nextLine();
                    sis.searchingStudentByID(searchId);
                    break;
                case 3:
                    sis.displayStudent();
                    break;
                case 4:
                    System.out.print("Enter Student ID: ");
                    String studentId = scanner.nextLine();
                    Student student = sis.getStudentByID(studentId);
                    if (student == null) {
                        System.out.println("Student not found.");
                        break;
                    }

                    System.out.print("Enter Course Code: ");
                    String courseCode = scanner.nextLine();
                    System.out.print("Enter Course Name: ");
                    String courseName = scanner.nextLine();
                    System.out.print("Enter Credit Hours: ");
                    int creditHours = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter Instructor Name: ");
                    String instructor = scanner.nextLine();
                    System.out.print("Enter Semester: ");
                    String semester = scanner.nextLine();
                    System.out.print("Enter Enrollment Status (e.g., active): ");
                    String status = scanner.nextLine();

                    Course course = new Course(courseCode, courseName, creditHours, instructor);
                    Enrollment enrollment = new Enrollment(student, course, semester, status);
                    sis.addEnrollment(enrollment);
                    System.out.println("Enrollment successful.");
                    break;
                case 0:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);

        scanner.close();
    }
}
