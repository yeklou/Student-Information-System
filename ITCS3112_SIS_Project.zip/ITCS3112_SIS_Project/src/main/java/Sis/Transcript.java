package Sis;

import java.util.HashMap;
import java.util.Map;

public class Transcript {
    private Map<Course, Grade> courseGrades = new HashMap<>();

    public void addGrade(Course course, Grade grade) {
        courseGrades.put(course, grade);
    }

    public void printTranscript() {
        double totalPoints = 0;
        int totalCredits = 0;

        for (Map.Entry<Course, Grade> entry : courseGrades.entrySet()) {
            Course course = entry.getKey();
            Grade grade = entry.getValue();
            course.displayCourseInfo();
            System.out.println("Score: " + grade.getScore() + ", Letter: " + grade.getLetterGrade());

            totalPoints += grade.getGradePoint() * course.getCreditHours();
            totalCredits += course.getCreditHours();
        }

        double gpa = totalCredits == 0 ? 0.0 : totalPoints / totalCredits;
        System.out.printf("GPA: %.2f\n", gpa);
    }
}
