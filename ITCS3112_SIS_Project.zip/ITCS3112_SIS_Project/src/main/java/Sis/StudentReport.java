package Sis;

public class StudentReport implements ReportGenerator {
    private Student student;

    public StudentReport(Student student) {
        this.student = student;
    }

    public void generateReport() {
        System.out.println("Student Report:");
        student.displayStudent();
    }
}

