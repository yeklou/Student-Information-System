package Sis;

import java.util.List;
import java.util.ArrayList;

public class Admin {
    private List<Student> students = new ArrayList<>();
    private List<Course> courses = new ArrayList<>();

    public void addStudent(Student student) {
        for (Student s : students) {
            if (s.getID().equals(student.getID())) {
                System.out.println("Duplicate student ID not allowed.");
                return;
            }
        }
        students.add(student);
        System.out.println("Student added.");
    }

    public void addCourse(Course course) {
        for (Course c : courses) {
            if (c.getCourseCode().equals(course.getCourseCode())) {
                System.out.println("Duplicate course code not allowed.");
                return;
            }
        }
        courses.add(course);
        System.out.println("Course added.");
    }

    public void removeStudent(String ID) {
        students.removeIf(s -> s.getID().equals(ID));
        System.out.println("Student removed if existed.");
    }

    public void updateStudentName(String ID, String newName) {
        for (Student s : students) {
            if (s.getID().equals(ID)) {
                s.setName(newName);
                System.out.println("Student name updated.");
                return;
            }
        }
        System.out.println("Student not found.");
    }
}
