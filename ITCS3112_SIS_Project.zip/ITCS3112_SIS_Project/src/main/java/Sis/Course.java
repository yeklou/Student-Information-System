package Sis;

import java.util.ArrayList;
import java.util.List;

public class Course {
    // Define course properties and methods
    private String courseCode;
    private String courseName;
    private int creditHours;
    private String instructor;
    private List<Student> enrolledStudents;

    public Course(String courseCode, String courseName, int creditHours, String instructor){
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.creditHours = creditHours;
        this.instructor = instructor;
        this.enrolledStudents = new ArrayList<>();
    }

    public String getCourseCode(){
        return courseCode;
    }

    public String getCourseName(){
        return courseName;
    }

    public int getCreditHours(){
        return creditHours;
    }

    public String getInstructor(){
        return instructor;
    }

    public void setCourseCode(String courseCode){
        this.courseCode = courseCode;
    }

    public void setCourseName(String courseName){
        this.courseName = courseName;
    }

    public void setCreditHours(int creditHours){
        this.creditHours = creditHours;
    }

    public void setInstructor(String instructor){
        this.instructor = instructor;
    }

    public void enrollStudent(Student student){
        enrolledStudents.add(student);
    }

    public List<Student> getEnrolledStudents(){
        return enrolledStudents;
    }

    public void displayCourseInfo(){
        System.out.println("Course Code: " + courseCode);
        System.out.println("Course Name: " + courseName);
        System.out.println("Credit Hours: " + creditHours);
        System.out.println("Instructor: " + instructor);
        System.out.println("Enrolled Students:");
        for(Student student : enrolledStudents){
            student.displayStudent();
        }
    }
}

