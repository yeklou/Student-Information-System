package Sis;

public class Enrollment {
    private Student student;
    private Course course;
    private String semester;
    private String status;

    public Enrollment(Student student, Course course, String semester, String status) {
        this.student = student;
        this.course = course;
        this.semester = semester;
        this.status = status;
    }

    public void displayEnrollmentInfo() {
        System.out.println("Enrollment: " + student.getName() + " in " + course.getCourseName() + ", Semester: " + semester + ", Status: " + status);
    }
}
