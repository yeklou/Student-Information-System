package Sis;

import org.junit.Before;
import org.junit.Test;

import src.main.java.Sis.Student;
import src.main.java.Sis.StudentInformationSystem;

import static org.junit.Assert.*;

public class StudentInformationSystemTest {

    private StudentInformationSystem sis;

    @Before
    public void setUp() {
        sis = new StudentInformationSystem();
        sis.addStudent(new Student("S001", "Alice"));
        sis.addStudent(new Student("S002", "Bob"));
    }

    @Test
    public void testSearchExistingStudent() {
        assertTrue(sis.searchingStudentByID("S001"));
    }

    @Test
    public void testSearchNonExistingStudent() {
        assertFalse(sis.searchingStudentByID("S999"));
    }

    @Test
    public void testAddDuplicateStudent() {
        sis.addStudent(new Student("S001", "Alice Duplicate"));
        int count = 0;
        for (Student s : sis.getAllStudents()) {
            if (s.getID().equals("S001")) {
                count++;
            }
        }
        assertTrue("There should be 2 students with ID S001", count == 2);
    }

    @Test
    public void testDisplayAllStudentsOutputNotEmpty() {
        // No assert — this is just to make sure no exception is thrown
        sis.displayStudent();
    }

    @Test
    public void testAddAndRetrieveStudentName() {
        sis.addStudent(new Student("S003", "Charlie"));
        assertTrue(sis.searchingStudentByID("S003"));
    }
}
